import os
import aiofiles
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from passlib.context import CryptContext
from typing import Optional, List
from uuid import uuid4, UUID as PyUUID
from datetime import datetime

from app.database import get_db
from app.models import User, UserAuth, AuditLog
from app.models.competence import Competence, UserCompetence
from app.services.jwt import get_current_user_id
from app.services.email import email_bienvenue
from app.services.onboarding_service import calculer_profile_completion, onboarding_est_complet
from app.schemas.user import UserCreate, UserUpdate, UserResponse, OnboardingPayload, DISPONIBILITE_VALIDES

router = APIRouter(prefix="/users", tags=["Utilisateurs"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ── Inscription ─────────────────────────────────────────────

@router.post("/", response_model=UserResponse, status_code=201)
async def create_user(
    request: Request,
    data: UserCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """Inscription d'un nouvel utilisateur."""
    if data.email:
        r = await db.execute(select(User).where(User.email == data.email))
        if r.scalars().first():
            raise HTTPException(status_code=400, detail="Cet email est déjà utilisé")

    r = await db.execute(select(UserAuth).where(UserAuth.telephone == data.telephone))
    if r.scalars().first():
        raise HTTPException(status_code=400, detail="Ce numéro est déjà utilisé")

    user_id = uuid4()
    mosala_id = 'MSL-' + ''.join(__import__('random').choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=8))
    user = User(
        id=user_id, nom=data.nom, prenom=data.prenom, postnom=data.postnom,
        email=data.email, telephone=data.telephone, ville=data.ville,
        mosala_id=mosala_id,
    )
    db.add(user)
    await db.flush()

    db.add(UserAuth(
        user_id=user_id, telephone=data.telephone,
        password_hash=pwd_context.hash(data.password),
    ))
    db.add(AuditLog(
        user_id=user_id, action="user_created", status="success",
        ip_address=request.client.host,
    ))
    await db.flush()

    if data.email:
        background_tasks.add_task(email_bienvenue, data.email, data.prenom)

    return user


# ── Profil public ───────────────────────────────────────────

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(user_id: str, db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(User).where(User.id == user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    return user


# ── Mise à jour profil ──────────────────────────────────────

@router.patch("/moi", response_model=UserResponse)
async def update_mon_profil(
    data: UserUpdate,
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Mettre à jour son propre profil."""
    if data.disponibilite and data.disponibilite not in DISPONIBILITE_VALIDES:
        raise HTTPException(
            status_code=400,
            detail=f"disponibilite doit être parmi {sorted(DISPONIBILITE_VALIDES)}",
        )

    r = await db.execute(select(User).where(User.id == current_user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")

    for field, value in data.dict(exclude_none=True).items():
        setattr(user, field, value)

    # Recalculer profile_completion à chaque update
    comps_r = await db.execute(
        select(UserCompetence).where(UserCompetence.user_id == str(user.id))
    )
    has_comps = bool(comps_r.scalars().first())
    user.profile_completion = calculer_profile_completion(
        account_type=user.account_type,
        competences=["x"] if has_comps else [],
        disponibilite=user.disponibilite,
        photo_url=user.photo_url,
        bio=user.bio,
    )
    user.updated_at = datetime.utcnow()
    await db.flush()
    return user


# ── Onboarding ──────────────────────────────────────────────

@router.post("/onboarding", response_model=UserResponse)
async def onboarding(
    data: OnboardingPayload,
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """
    Étape onboarding après inscription.
    Sauvegarde : account_type, compétences, disponibilite.
    Calcule : profile_completion, onboarding_done.
    Tout dans une seule transaction DB.
    """
    # Validation
    if data.account_type not in ("freelance", "client"):
        raise HTTPException(status_code=400, detail="account_type doit être 'freelance' ou 'client'")
    if data.disponibilite and data.disponibilite not in DISPONIBILITE_VALIDES:
        raise HTTPException(
            status_code=400,
            detail=f"disponibilite invalide. Valeurs: {sorted(DISPONIBILITE_VALIDES)}",
        )
    if len(data.competences) > 5:
        raise HTTPException(status_code=400, detail="Maximum 5 compétences")

    r = await db.execute(select(User).where(User.id == current_user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")

    # 1. Mettre à jour l'utilisateur
    user.account_type  = data.account_type
    user.disponibilite = data.disponibilite
    user.delai_reponse = data.delai_reponse
    user.updated_at    = datetime.utcnow()

    # 2. Ajouter les compétences (transaction safe)
    comp_names = [c.strip() for c in data.competences[:5] if c.strip()]
    for nom in comp_names:
        # Chercher ou créer la compétence
        r_comp = await db.execute(select(Competence).where(Competence.nom == nom))
        comp = r_comp.scalars().first()
        if not comp:
            comp = Competence(nom=nom, categorie="general")
            db.add(comp)
            await db.flush()

        # Éviter les doublons
        r_uc = await db.execute(
            select(UserCompetence)
            .where(UserCompetence.user_id == str(user.id))
            .where(UserCompetence.competence_id == comp.id)
        )
        if not r_uc.scalars().first():
            db.add(UserCompetence(
                user_id=str(user.id),
                competence_id=comp.id,
                niveau=1,
                valide_admin=False,
            ))

    await db.flush()

    # 3. Calculer profile_completion et onboarding_done
    user.profile_completion = calculer_profile_completion(
        account_type=user.account_type,
        competences=comp_names,
        disponibilite=user.disponibilite,
        photo_url=user.photo_url,
        bio=user.bio,
    )
    user.onboarding_done = onboarding_est_complet(
        account_type=user.account_type,
        competences=comp_names,
        disponibilite=user.disponibilite,
    )
    await db.flush()

    return user


# ── Statut en ligne ─────────────────────────────────────────

@router.patch("/moi/online", response_model=UserResponse)
async def update_online_status(
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Met à jour last_seen et is_online = True."""
    r = await db.execute(select(User).where(User.id == current_user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    user.last_seen = datetime.utcnow()
    user.is_online = True
    await db.flush()
    return user

@router.put("/me")
async def update_me_put(
    data: UserUpdate,
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    return await update_mon_profil(data, current_user_id, db)


# ── KYC — Soumission documents ───────────────────────────────────────────────

KYC_UPLOAD_DIR = "/opt/mosala/uploads/kyc"

@router.post("/me/kyc")
async def soumettre_kyc(
    recto:          UploadFile = File(...),
    verso:          UploadFile = File(...),
    selfie:         UploadFile = File(...),
    nom:            str = Form(None),
    prenom:         str = Form(None),
    postnom:        str = Form(None),
    date_naissance: str = Form(None),
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Soumettre les documents KYC (recto, verso, selfie, postnom, date_naissance)."""

    r = await db.execute(select(User).where(User.id == current_user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    if user.kyc_status == "valide":
        raise HTTPException(status_code=400, detail="KYC déjà validé")

    user_dir = os.path.join(KYC_UPLOAD_DIR, str(current_user_id))
    os.makedirs(user_dir, exist_ok=True)

    saved = {}
    for label, f in [("recto", recto), ("verso", verso), ("selfie", selfie)]:
        ext = (f.filename or ".jpg").rsplit(".", 1)[-1].lower()
        if ext not in {"jpg", "jpeg", "png", "webp"}:
            raise HTTPException(status_code=400, detail=f"{label} : format non supporté")
        dest = os.path.join(user_dir, f"{label}.{ext}")
        content = await f.read()
        if len(content) > 8 * 1024 * 1024:
            raise HTTPException(status_code=400, detail=f"{label} trop lourd (max 8MB)")
        async with aiofiles.open(dest, "wb") as out:
            await out.write(content)
        saved[label] = dest

    user.kyc_status       = "en_attente"
    user.kyc_recto_url    = saved["recto"]
    user.kyc_verso_url    = saved["verso"]
    user.kyc_selfie_url   = saved["selfie"]
    user.kyc_submitted_at = datetime.utcnow()
    user.kyc_note         = None
    # Sauvegarder postnom et date_naissance si fournis
    if nom:
        user.nom = nom.strip()
    if prenom:
        user.prenom = prenom.strip()
    if postnom:
        user.postnom = postnom.strip()
    if date_naissance:
        from datetime import date as date_type
        try:
            user.date_naissance = date_type.fromisoformat(date_naissance)
        except ValueError:
            pass
    await db.flush()

    return {"status": "en_attente", "message": "Documents reçus — vérification sous 24-48h"}
