"""
Router Admin — Mosala
Endpoints protégés par rôle admin.
Ajouter ici toutes les fonctionnalités d'administration.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func
from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID as PyUUID
from datetime import datetime

from app.database import get_db
from app.models import User
from app.models.transaction import Transaction
from app.models.notification import Notification
from app.services.email import send_kyc_valide, send_kyc_rejete
from app.services.notifications import create_notification
from app.services.jwt import get_current_user_id

router = APIRouter(prefix="/admin", tags=["Admin"])


async def require_admin(
    current_user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Dépendance : vérifie que l'utilisateur est admin."""
    r = await db.execute(select(User).where(User.id == current_user_id))
    user = r.scalars().first()
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Accès réservé aux administrateurs")
    return current_user_id


class UserAdminResponse(BaseModel):
    id: PyUUID
    nom: str
    prenom: str
    email: Optional[str] = None
    telephone: Optional[str] = None
    statut: str
    role: str
    is_active: bool
    created_at: datetime
    class Config:
        from_attributes = True


@router.get("/stats")
async def admin_stats(
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Statistiques globales de la plateforme."""
    total_users = await db.execute(select(func.count(User.id)).where(User.role == "user"))
    total_tx = await db.execute(select(func.count(Transaction.id)))
    total_frais = await db.execute(select(func.sum(Transaction.frais_mosala)).where(Transaction.statut == "success"))
    notifs_non_lues = await db.execute(select(func.count(Notification.id)).where(Notification.lu == False))

    return {
        "total_users": total_users.scalar(),
        "total_transactions": total_tx.scalar(),
        "total_frais_plateforme": float(total_frais.scalar() or 0),
        "notifications_non_lues": notifs_non_lues.scalar(),
        "kyc_en_attente": (await db.execute(select(func.count(User.id)).where(User.kyc_status == "en_attente"))).scalar(),
    }


@router.get("/users", response_model=List[UserAdminResponse])
async def admin_list_users(
    statut: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Liste tous les utilisateurs (admin seulement)."""
    query = select(User).where(User.role == "user")
    if statut:
        query = query.where(User.statut == statut)
    query = query.order_by(User.created_at.desc()).limit(limit).offset(offset)
    r = await db.execute(query)
    return r.scalars().all()


@router.patch("/users/{user_id}/statut")
async def admin_update_user_status(
    user_id: str,
    statut: str,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Changer le statut d'un utilisateur (actif/suspendu/vip)."""
    if statut not in ("actif", "suspendu", "vip"):
        raise HTTPException(status_code=400, detail="Statut: actif | suspendu | vip")
    r = await db.execute(select(User).where(User.id == user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    user.statut = statut
    user.updated_at = datetime.utcnow()

    # Notification automatique à l'utilisateur
    import uuid as _uuid
    msg_map = {
        "actif":    ("✅ Compte activé",    "Votre compte Mosala a été activé. Vous pouvez maintenant accéder à toutes les fonctionnalités.", "success"),
        "suspendu": ("⛔ Compte suspendu",   "Votre compte Mosala a été suspendu. Contactez le support pour plus d'informations.",           "warning"),
        "vip":      ("⭐ Compte VIP",        "Félicitations ! Votre compte a été promu au statut VIP. Profitez de vos avantages exclusifs.", "promo"),
    }
    titre, message, ntype = msg_map.get(statut, ("Mise à jour de compte", "Votre statut a été mis à jour.", "info"))
    db.add(Notification(
        id=_uuid.uuid4(),
        user_id=user.id,
        titre=titre,
        message=message,
        type=ntype,
        lu=False,
    ))

    await db.flush()
    return {"ok": True, "user_id": user_id, "new_statut": statut}


@router.get("/notifications/list")
async def admin_list_notifications(
    limit: int = 50,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Liste les notifications récentes (admin)."""
    from sqlalchemy import desc
    r = await db.execute(
        select(Notification).order_by(desc(Notification.created_at)).limit(limit)
    )
    notifs = r.scalars().all()
    return [
        {
            "id": str(n.id),
            "user_id": str(n.user_id),
            "titre": n.titre,
            "message": n.message,
            "type": n.type,
            "lu": n.lu,
            "created_at": n.created_at.isoformat() if n.created_at else None,
        }
        for n in notifs
    ]

# ── Envoyer une notification (in-app / email / les deux) ─────────────────────

class SendNotifRequest(BaseModel):
    titre: str
    message: str
    type: str = "info"           # info | success | warning | promo
    canal: str = "inapp"         # inapp | email | both
    user_id: Optional[str] = None   # None = tous les users actifs


@router.post("/notifications/send")
async def admin_send_notification(
    body: SendNotifRequest,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Envoie une notification in-app et/ou par email à un ou tous les users."""
    from app.services.email import send_email, _html_wrapper
    import uuid as _uuid

    # Récupérer la liste des destinataires
    if body.user_id:
        r = await db.execute(
            select(User).where(User.id == body.user_id, User.role == "user")
        )
        users = r.scalars().all()
    else:
        r = await db.execute(
            select(User).where(User.role == "user", User.statut != "suspendu")
        )
        users = r.scalars().all()

    if not users:
        raise HTTPException(status_code=404, detail="Aucun utilisateur trouvé")

    sent = 0
    for user in users:
        # ── Canal in-app ──
        if body.canal in ("inapp", "both"):
            notif = Notification(
                id=_uuid.uuid4(),
                user_id=user.id,
                titre=body.titre,
                message=body.message,
                type=body.type,
                lu=False,
            )
            db.add(notif)

        # ── Canal email ──
        if body.canal in ("email", "both") and user.email:
            TYPE_EMOJI = {
                "info": "ℹ️", "success": "✅",
                "warning": "⚠️", "promo": "🎁",
            }
            emoji = TYPE_EMOJI.get(body.type, "📢")
            html = _html_wrapper(f"""
                <h2 style="color:#111;margin-top:0;">{emoji} {body.titre}</h2>
                <p>Bonjour <strong>{user.prenom}</strong>,</p>
                <div style="background:#f0fdf4;border-left:4px solid #16a34a;
                            padding:16px;border-radius:8px;margin:16px 0;
                            color:#374151;line-height:1.7;">
                    {body.message}
                </div>
                <a href="https://mosala.io"
                   style="display:inline-block;background:#16a34a;color:#fff;
                          padding:12px 24px;border-radius:8px;
                          text-decoration:none;font-weight:bold;">
                    Voir sur Mosala →
                </a>
            """)
            await send_email(user.email, f"{emoji} {body.titre} — Mosala", html)

        sent += 1

    await db.flush()
    return {"ok": True, "sent": sent}

# ── RECHERCHE GLOBALE ────────────────────────────────────────────────────────

@router.get("/search")
async def admin_search(
    q: str = "",
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    from app.models import Opportunity
    from sqlalchemy import or_
    results = {"users": [], "jobs": []}
    if not q or len(q) < 2:
        return results
    term = f"%{q.lower()}%"

    r = await db.execute(
        select(User).where(
            or_(
                func.lower(User.prenom).like(term),
                func.lower(User.nom).like(term),
                func.lower(User.email).like(term),
            )
        ).limit(8)
    )
    results["users"] = [
        {"id": str(u.id), "prenom": u.prenom, "nom": u.nom, "email": u.email, "role": u.role, "statut": u.statut}
        for u in r.scalars().all()
    ]

    r2 = await db.execute(
        select(Opportunity).where(
            or_(
                func.lower(Opportunity.title).like(term),
                func.lower(Opportunity.company).like(term),
                func.lower(Opportunity.location).like(term),
            )
        ).order_by(Opportunity.created_at.desc()).limit(8)
    )
    results["jobs"] = [
        {"id": str(j.id), "title": j.title, "company": j.company, "location": j.location, "status": j.status, "opportunity_type": j.opportunity_type}
        for j in r2.scalars().all()
    ]
    return results


# ── LOGS D ACTIVITE ──────────────────────────────────────────────────────────

@router.get("/logs")
async def admin_get_logs(
    limit: int = 50,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import text
    try:
        r = await db.execute(
            text("""
                SELECT al.id, al.action, al.ip_address, al.created_at, al.status,
                       u.prenom, u.nom, u.email, u.role
                FROM audit_logs al
                LEFT JOIN users u ON u.id = al.user_id
                ORDER BY al.created_at DESC
                LIMIT :limit
            """),
            {"limit": limit}
        )
        rows = r.fetchall()
        return [
            {
                "id": str(row.id),
                "action": row.action,
                "ip": row.ip_address,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "status": row.status,
                "user_prenom": row.prenom or "",
                "user_nom": row.nom or "",
                "user_email": row.email or "",
                "user_role": row.role or "",
            }
            for row in rows
        ]
    except Exception:
        return []


# ── KYC Admin ─────────────────────────────────────────────

@router.get("/kyc")
async def admin_list_kyc(
    statut: str = "en_attente",
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    from sqlalchemy.future import select
    r = await db.execute(
        select(User).where(User.kyc_status == statut).order_by(User.kyc_submitted_at.desc())
    )
    users = r.scalars().all()
    return [
        {
            "id": str(u.id),
            "prenom": u.prenom,
            "postnom": u.postnom or "",
            "nom": u.nom,
            "email": u.email or "",
            "telephone": u.telephone or "",
            "ville": u.ville or "",
            "date_naissance": u.date_naissance.isoformat() if u.date_naissance else "",
            "kyc_status": u.kyc_status,
            "kyc_note": u.kyc_note or "",
            "kyc_submitted_at": u.kyc_submitted_at.isoformat() if u.kyc_submitted_at else "",
            "kyc_recto_url": u.kyc_recto_url or "",
            "kyc_verso_url": u.kyc_verso_url or "",
            "kyc_selfie_url": u.kyc_selfie_url or "",
        }
        for u in users
    ]


@router.patch("/kyc/{user_id}")
async def admin_update_kyc(
    user_id: str,
    statut: str,
    note: str = "",
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    from sqlalchemy.future import select
    r = await db.execute(select(User).where(User.id == user_id))
    user = r.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouve")

    user.kyc_status = statut
    user.kyc_note = note
    await db.flush()

    prenom = user.prenom or "Utilisateur"

    # ── Notification sur le site ───────────────────────────
    if statut == "valide":
        msg_notif = "✅ Votre identité a été vérifiée ! Vous avez maintenant le badge Vérifié."
    else:
        msg_notif = f"❌ Votre vérification d'identité a été refusée. Motif : {note or 'Documents non conformes'}."

    try:
        titre_notif = "Identite verifiee" if statut == "valide" else "Verification refusee"
        await create_notification(db, user_id=str(user.id), titre=titre_notif, message=msg_notif, type="kyc")
    except Exception:
        pass

    # ── Email ──────────────────────────────────────────────
    if user.email:
        try:
            if statut == "valide":
                await send_kyc_valide(user.email, prenom)
            else:
                await send_kyc_rejete(user.email, prenom, note or "Documents non conformes")
        except Exception:
            pass

    return {"ok": True, "kyc_status": statut}


# ── KYC File Viewer ───────────────────────────────────────

@router.get("/kyc-file")
async def serve_kyc_file(
    path: str,
    _: User = Depends(require_admin),
):
    """Servir un fichier KYC stocké sur le disque (admin seulement)."""
    import os
    from fastapi.responses import FileResponse

    # Sécurité : le path doit être dans le dossier KYC
    KYC_BASE = "/opt/mosala/uploads/kyc"
    abs_path = os.path.realpath(path)

    if not abs_path.startswith(KYC_BASE):
        raise HTTPException(status_code=403, detail="Acces interdit")

    if not os.path.isfile(abs_path):
        raise HTTPException(status_code=404, detail="Fichier non trouve")

    ext = abs_path.rsplit(".", 1)[-1].lower()
    mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}.get(ext, "application/octet-stream")

    return FileResponse(abs_path, media_type=mime)
