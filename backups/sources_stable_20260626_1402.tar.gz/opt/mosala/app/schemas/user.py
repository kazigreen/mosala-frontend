from pydantic import BaseModel
from typing import Optional, List
from uuid import UUID as PyUUID
from datetime import datetime, date

DISPONIBILITE_VALIDES = {"maintenant", "cette_semaine", "temps_partiel", "temps_plein"}
ACCOUNT_TYPE_VALIDES  = {"freelance", "client"}


# ── Réponse utilisateur ────────────────────────────────────

class UserResponse(BaseModel):
    id:                 PyUUID
    nom:                str
    prenom:             str
    postnom:            Optional[str]          = None
    email:              Optional[str]          = None
    telephone:          Optional[str]          = None
    ville:              Optional[str]          = None
    date_naissance:     Optional[date]         = None
    bio:                Optional[str]          = None
    photo_url:          Optional[str]          = None
    statut:             str
    role:               str                    = "user"
    account_type:       Optional[str]          = None
    mosala_id:          Optional[str]          = None
    kyc_status:         Optional[str]          = "non_soumis"
    kyc_note:           Optional[str]          = None
    onboarding_done:    bool                   = False
    profile_completion: int                    = 0
    disponibilite:      Optional[str]          = None
    delai_reponse:      Optional[str]          = None
    is_online:          bool                   = False
    last_seen:          Optional[datetime]     = None
    is_active:          bool                   = True
    created_at:         datetime

    class Config:
        from_attributes = True


# ── Création utilisateur ───────────────────────────────────

class UserCreate(BaseModel):
    nom:      str
    prenom:   str
    postnom:  Optional[str] = None
    email:    Optional[str] = None
    telephone: str
    ville:    Optional[str] = None
    password: str


# ── Mise à jour profil ─────────────────────────────────────

class UserUpdate(BaseModel):
    nom:          Optional[str] = None
    prenom:       Optional[str] = None
    bio:          Optional[str] = None
    ville:        Optional[str] = None
    date_naissance: Optional[str] = None
    disponibilite: Optional[str] = None
    photo_url:    Optional[str] = None

    def validate_disponibilite(self):
        if self.disponibilite and self.disponibilite not in DISPONIBILITE_VALIDES:
            raise ValueError(f"disponibilite doit être parmi {DISPONIBILITE_VALIDES}")


# ── Onboarding ─────────────────────────────────────────────

class OnboardingPayload(BaseModel):
    account_type:  str
    competences:   List[str] = []          # max 5 noms de compétences
    disponibilite: Optional[str] = None
    delai_reponse: Optional[str] = None

    def validate_fields(self):
        if self.account_type not in ACCOUNT_TYPE_VALIDES:
            raise ValueError(f"account_type doit être 'freelance' ou 'client'")
        if self.disponibilite and self.disponibilite not in DISPONIBILITE_VALIDES:
            raise ValueError(f"disponibilite invalide")
        if len(self.competences) > 5:
            raise ValueError("Maximum 5 compétences")
