from sqlalchemy import Column, String, Boolean, SmallInteger, DateTime, Date, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from datetime import datetime
from uuid import uuid4
from app.database import Base


class Commune(Base):
    __tablename__ = "communes"
    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    nom        = Column(String(100), nullable=False)
    region     = Column(String(100))
    pays       = Column(String(50), default="RDC")
    created_at = Column(DateTime, default=datetime.utcnow)


class User(Base):
    __tablename__ = "users"
    id                  = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    nom                 = Column(String(100), nullable=False)
    prenom              = Column(String(100), nullable=False)
    postnom             = Column(String(100))
    email               = Column(String(150), unique=True)
    telephone           = Column(String(20))
    ville               = Column(String(100))
    date_naissance      = Column(Date, nullable=True)
    commune_id          = Column(UUID(as_uuid=True), ForeignKey("communes.id"), nullable=True)
    niveau_verification = Column(SmallInteger, default=0)
    is_active           = Column(Boolean, default=True)
    disponibilite       = Column(String(50))          # maintenant|cette_semaine|temps_partiel|temps_plein
    statut              = Column(String(50), default="actif")
    role                = Column(String(20), default="user")        # user | admin | moderator
    account_type        = Column(String(20))                        # freelance | client
    onboarding_done     = Column(Boolean, default=False)
    profile_completion  = Column(SmallInteger, default=0)           # 0 → 100
    delai_reponse       = Column(String(50))                        # moins_24h | 1_3_jours
    last_seen           = Column(DateTime)
    is_online           = Column(Boolean, default=False)
    profil_public       = Column(Boolean, default=True)
    photo_url           = Column(Text)
    kyc_status          = Column(String(20), default="non_soumis")
    kyc_note            = Column(Text)
    kyc_recto_url       = Column(Text)
    kyc_verso_url       = Column(Text)
    kyc_selfie_url      = Column(Text)
    kyc_submitted_at    = Column(DateTime)
    google_id           = Column(String(255), unique=True, nullable=True)
    bio                 = Column(Text)
    created_at          = Column(DateTime, default=datetime.utcnow)
    updated_at          = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class UserAuth(Base):
    __tablename__ = "user_auth"
    id                 = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id            = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    telephone          = Column(String(20), unique=True, nullable=False)
    password_hash      = Column(Text, nullable=False)
    secret_2fa         = Column(Text)
    token_session      = Column(Text)
    derniere_connexion = Column(DateTime)
    created_at         = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    action     = Column(String(100), nullable=False)
    status     = Column(String(50), default="success")
    details    = Column(JSONB)
    ip_address = Column(String(45))
    created_at = Column(DateTime, default=datetime.utcnow)


class CV_IA(Base):
    __tablename__ = "cv_ia"
    id             = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id        = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    donnees_ia     = Column(Text)
    resume_genere  = Column(Text)
    score_matching = Column(SmallInteger, default=0)
    updated_at     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
